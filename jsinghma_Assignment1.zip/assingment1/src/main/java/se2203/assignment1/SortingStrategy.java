package se2203.assignment1;

public interface SortingStrategy extends Runnable{
    public void Sort(int [] numbers);


}
